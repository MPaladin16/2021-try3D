# Get the most up to date documentation here
[Documentation]https://docs.google.com/document/d/1NDKeUZM8mHcJMX8LDJuUrFCz8jIuhv3hR8bSnol48a8/edit?usp=sharing)

# Important! Using the demo scenes
The demo scenes use external libraries to enable basic controls for touch support.  You'll need to import the
required libraries for your use case, and select the correct option in Windows -> Easy Grab SDK.  Please check the
full documentation for more information.
